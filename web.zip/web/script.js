const defaultApiData = [
  {id: 1, name: "Leanne Graham", username: "Bret", email: "Sincere@april.biz", phone: "1-770-736-8031"},
  {id: 2, name: "Ervin Howell", username: "Antonette", email: "Shanna@melissa.tv", phone: "010-692-6593"},
  {id: 3, name: "Clementine Bauch", username: "Samantha", email: "Nathan@yesenia.net", phone: "1-463-123-4447"},
  {id: 4, name: "Patricia Lebsack", username: "Karianne", email: "Julianne@kory.org", phone: "493-170-9623"},
  {id: 5, name: "Chelsey Dietrich", username: "Kamren", email: "Lucio@annie.ca", phone: "(254)954-1289"},
  {id: 6, name: "Dennis Schulist", username: "Leopoldo", email: "Karley@jasper.info", phone: "1-477-935-8478"},
  {id: 7, name: "Kurtis Weissnat", username: "Elwyn", email: "Telly@billy.biz", phone: "210.067.6132"},
  {id: 8, name: "Nicholas Runolfs", username: "Maxime", email: "Sherwood@rosamond.me", phone: "586.493.6943"},
  {id: 9, name: "Glenna Reichert", username: "Delphine", email: "Chaim@dana.io", phone: "(775)976-6794"},
  {id: 10, name: "Clementina DuBuque", username: "Moriah", email: "Rey@karina.biz", phone: "024-648-3804"}
];

let apiData = JSON.parse(localStorage.getItem("apiData"));
if (!apiData || apiData.length === 0) {
  apiData = defaultApiData;
  localStorage.setItem("apiData", JSON.stringify(apiData));
}

function renderTable() {
  const tableBody = document.getElementById("userTableBody");
  if (!tableBody) return;
  tableBody.innerHTML = "";
  apiData.forEach((user, index) => {
    tableBody.innerHTML += `
      <tr>
        <td>${user.id}</td>
        <td>${user.name}</td>
        <td>${user.username}</td>
        <td>${user.email}</td>
        <td>${user.phone}</td>
        <td>
          <button class="edit-btn" onclick="goToEdit(${index})">Edit</button>
          <button class="delete-btn" onclick="deleteUser(${index})">Delete</button>
        </td>
      </tr>
    `;
  });
}

function deleteUser(index) {
  apiData.splice(index, 1);
  localStorage.setItem("apiData", JSON.stringify(apiData));
  renderTable();
}

function goToAdd() {
  window.location.href = "add.html";
}

function goToEdit(index) {
  localStorage.setItem("editUserIndex", index);
  window.location.href = "edit.html";
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("userTableBody")) {
    renderTable();
  }

  const addForm = document.getElementById("addForm");
  if (addForm) {
    addForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const newUser = {
        id: apiData.length ? apiData[apiData.length - 1].id + 1 : 1,
        name: document.getElementById("name").value,
        username: document.getElementById("username").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
      };
      apiData.push(newUser);
      localStorage.setItem("apiData", JSON.stringify(apiData));
      window.location.href = "index.html";
    });
  }

  const editForm = document.getElementById("editForm");
  if (editForm) {
    const index = localStorage.getItem("editUserIndex");
    if (index !== null) {
      const user = apiData[index];
      document.getElementById("editName").value = user.name;
      document.getElementById("editUsername").value = user.username;
      document.getElementById("editEmail").value = user.email;
      document.getElementById("editPhone").value = user.phone;

      editForm.addEventListener("submit", (e) => {
        e.preventDefault();
        apiData[index] = {
          ...user,
          name: document.getElementById("editName").value,
          username: document.getElementById("editUsername").value,
          email: document.getElementById("editEmail").value,
          phone: document.getElementById("editPhone").value
        };
        localStorage.setItem("apiData", JSON.stringify(apiData));
        localStorage.removeItem("editUserIndex");
        window.location.href = "index.html";
      });
    }
  }
});
